const initProject = () => {
  localStorage.setItem("appUrl", "http://localhost:8080")
}

initProject()
