package com.company.project.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * DishesEditReq
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DishesEditReq {


    @NotBlank(message = "菜品code不能为空")
    @NotNull(message = "菜品code不能为空")
    private String code;


    @NotBlank(message = "菜品名称不能为空")
    @NotNull(message = "菜品名称不能为空")
    private String name;


    @NotBlank(message = "菜品图片不能为空")
    @NotNull(message = "菜品图片不能为空")
    private String url;


    @NotBlank(message = "菜品价格不能为空")
    @NotNull(message = "菜品价格不能为空")
    private String price;


    private String description;
}
