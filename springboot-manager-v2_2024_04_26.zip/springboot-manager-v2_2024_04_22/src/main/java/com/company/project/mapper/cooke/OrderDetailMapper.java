package com.company.project.mapper.cooke;


import com.company.project.entity.cooke.OrderDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface OrderDetailMapper extends BaseMapper<OrderDetail> {

}