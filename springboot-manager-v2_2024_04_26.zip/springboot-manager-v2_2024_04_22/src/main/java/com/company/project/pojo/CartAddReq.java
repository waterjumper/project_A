package com.company.project.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * CartAddReq
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartAddReq {

    @NotBlank(message = "productCode不能为空")
    @NotNull(message = "productCode不能为空")
    private String productCode;

    @NotNull(message = "quantity不能为空")
    private Integer quantity;
}
