package com.company.project.controller.api;


import com.company.project.common.utils.DataResult;
import com.company.project.pojo.CartAddReq;
import com.company.project.pojo.CartQueryReq;
import com.company.project.service.cooke.CartService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * CartController
 */
@RestController
@Api(tags = "c端购物车管理")
@RequestMapping("/cart/api")
@Slf4j
public class CartController {


    @Resource
    private CartService cartService;



    @PostMapping("/list")
    @ApiOperation(value = "购物车列表")
    public DataResult cartList(@RequestBody @Valid CartQueryReq vo) {
        return DataResult.success(cartService.pageList(vo));
    }


    @PostMapping(value = "/add")
    @ApiOperation(value = "购物车添加")
    public DataResult add(@RequestBody @Valid CartAddReq req) {
        return DataResult.success(cartService.add(req));
    }

}
