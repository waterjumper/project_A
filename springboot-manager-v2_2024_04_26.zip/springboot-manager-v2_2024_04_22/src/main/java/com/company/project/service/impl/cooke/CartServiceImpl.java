package com.company.project.service.impl.cooke;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.company.project.common.exception.BusinessException;
import com.company.project.common.exception.code.BaseResponseCode;
import com.company.project.common.utils.Constant;
import com.company.project.common.utils.ToolUtils;
import com.company.project.entity.cooke.Cart;
import com.company.project.entity.cooke.Dishes;
import com.company.project.mapper.cooke.CartMapper;
import com.company.project.mapper.cooke.DishesMapper;
import com.company.project.pojo.CartAddReq;
import com.company.project.pojo.CartListResponse;
import com.company.project.pojo.CartQueryReq;
import com.company.project.service.HttpSessionService;
import com.company.project.service.cooke.CartService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;


/**
 * CartServiceImpl
 */
@Service
@Slf4j
public class CartServiceImpl extends ServiceImpl<CartMapper, Cart> implements CartService {

    @Resource
    private CartMapper cartMapper;


    @Resource
    private DishesMapper dishesMapper;

    @Resource
    private HttpSessionService httpSessionService;

    /**
     * 分页查询
     *
     * @param vo
     * @return
     */
    @Override
    public IPage<CartListResponse> pageList(CartQueryReq vo) {
        Long currentUserId = httpSessionService.getCurrentUserIdAndCheck();
        log.info("cart pageList currentUserId:{}", currentUserId);

        Page<Cart> page = new Page<>(vo.getPage(), vo.getLimit());

        LambdaQueryWrapper<Cart> queryWrapper = Wrappers.lambdaQuery();
        queryWrapper.eq(Cart::getUserId, currentUserId).select(Cart::getId, Cart::getProductCode, Cart::getQuantity, Cart::getUnitPrice);
        queryWrapper.orderByDesc(Cart::getId);


        Page<Cart> cartPage = cartMapper.selectPage(page, queryWrapper);
        List<Cart> records = cartPage.getRecords();

        Page<CartListResponse> cartListResponsePage = new Page<>();
        cartListResponsePage.setTotal(cartPage.getTotal());
        cartListResponsePage.setSize(cartPage.getSize());
        cartListResponsePage.setCurrent(cartPage.getCurrent());
        cartListResponsePage.setPages(cartPage.getPages());
        if (CollectionUtils.isEmpty(records)) {
            return cartListResponsePage;
        }

        Set<String> productCodes = records.stream().map(Cart::getProductCode).collect(Collectors.toSet());
        LambdaQueryWrapper<Dishes> dishesQueryWrapper = Wrappers.lambdaQuery();
        dishesQueryWrapper.in(Dishes::getCode, productCodes)
                .select(Dishes::getCode, Dishes::getName, Dishes::getUrl);

        Map<String, Dishes> dishesMap = dishesMapper.selectList(dishesQueryWrapper).stream()
                .collect(Collectors.toMap(Dishes::getCode, Function.identity()));


        List<CartListResponse> cartListResponseList = records.stream().map(item -> {
                    CartListResponse cartListResponse = new CartListResponse();
                    cartListResponse.setId(item.getId());
                    cartListResponse.setProductCode(item.getProductCode());
                    cartListResponse.setQuantity(item.getQuantity());
                    cartListResponse.setUnitPrice(item.getUnitPrice());

                    Dishes dishes = dishesMap.get(item.getProductCode());
                    if (Objects.nonNull(dishes)){
                        cartListResponse.setProductUrl(dishes.getUrl());
                        cartListResponse.setProductName(dishes.getName());
                    }
                    return cartListResponse;
                })
                .collect(Collectors.toList());

        cartListResponsePage.setRecords(cartListResponseList);
        return cartListResponsePage;

    }


    @Override
    public boolean add(CartAddReq vo) {
        Long currentUserId = httpSessionService.getCurrentUserIdAndCheck();
        log.info("cart add currentUserId:{}", currentUserId);

        LambdaQueryWrapper<Dishes> queryWrapper = Wrappers.lambdaQuery();
        queryWrapper.eq(Dishes::getCode, vo.getProductCode()).last(Constant.LIMIT_1);

        Dishes dishes = dishesMapper.selectOne(queryWrapper);
        if (Objects.isNull(dishes)) {
            throw new BusinessException(BaseResponseCode.DISHED_NOT_EXIXT);
        }

        Cart newCart = new Cart();
        newCart.setUserId(currentUserId);
        newCart.setProductCode(vo.getProductCode());
        newCart.setQuantity(vo.getQuantity());
        newCart.setUnitPrice(dishes.getPrice());
        newCart.setCtime(ToolUtils.timestamp2());
        newCart.setUtime(ToolUtils.timestamp2());

        return cartMapper.insertOrUpdateAuantity(newCart) > 0;
    }
}
