package com.company.project.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OrderCreateResp
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderCreateResp {


    private String orderCode;

}
