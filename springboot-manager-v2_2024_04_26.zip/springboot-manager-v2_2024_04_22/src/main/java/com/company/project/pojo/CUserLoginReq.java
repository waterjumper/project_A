package com.company.project.pojo;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * CUserLoginReq
 *
 */
@Data
public class CUserLoginReq {


    @NotBlank(message = "手机号不能为空")
    @NotNull(message = "手机号不能为空")
    private String phone;

    @NotBlank(message = "密码不能为空")
    @NotNull(message = "密码不能为空")
    private String password;

}
