package com.company.project.pojo;

import lombok.Data;

/**
 * CartQueryReq
 *
 */
@Data
public class CartQueryReq extends QueryBase{

    public CartQueryReq() {
        super();
    }

}
