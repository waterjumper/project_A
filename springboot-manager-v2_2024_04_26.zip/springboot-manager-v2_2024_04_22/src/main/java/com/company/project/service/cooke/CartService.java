package com.company.project.service.cooke;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.cooke.Cart;
import com.company.project.pojo.CartAddReq;
import com.company.project.pojo.CartListResponse;
import com.company.project.pojo.CartQueryReq;


/**
 * CartService
 */
public interface CartService extends IService<Cart> {

    IPage<CartListResponse> pageList(CartQueryReq vo);


    boolean add(CartAddReq vo);
}
