package com.company.project.mapper.cooke;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.company.project.entity.SysUser;
import com.company.project.entity.cooke.CUser;

/**
 * c端用户 Mapper
 *
 */
public interface CUserMapper extends BaseMapper<CUser> {

}