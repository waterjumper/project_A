package com.company.project.mapper.cooke;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.company.project.entity.cooke.Order;


public interface OrderMapper extends BaseMapper<Order> {

}