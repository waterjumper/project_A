package com.company.project.mapper.cooke;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.company.project.entity.cooke.CUser;
import com.company.project.entity.cooke.Dishes;


public interface DishesMapper extends BaseMapper<Dishes> {

}